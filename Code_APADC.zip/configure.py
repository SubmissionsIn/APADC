def get_default_config(data_name):
    if data_name in ['MNIST-USPS']:
        return dict(
            Autoencoder=dict(
                arch1=[784, 1024, 1024, 1024, 32],
                arch2=[784, 1024, 1024, 1024, 32],
                activations1='relu',
                activations2='relu',
                batchnorm=True,
            ),
            training=dict(
                missing_rate=0.3,
                seed=6,
                batch_size=256,
                epoch=500,
                lr=1.0e-4,
                lambda1=100,
                lambda2=0.1,
                kernel_mul=2,
                kernel_num=6,
            ),
        )

    else:
        raise Exception('Undefined data_name')
