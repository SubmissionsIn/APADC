import os, sys
import numpy as np
import scipy.io as sio


def load_data(config):
    """Load data """
    data_name = config['dataset']
    main_dir = sys.path[0]
    X_list = []
    Y_list = []

    if data_name in ['MNIST-USPS']:
        mat = sio.loadmat(os.path.join(main_dir, 'data', data_name + '.mat'))
        X_list.append(mat['X1'].astype('float32'))          # (5000,784)
        X_list.append(mat['X2'].astype('float32'))          # (5000,784)
        Y_list.append(np.squeeze(mat['Y']))

    return X_list, Y_list
