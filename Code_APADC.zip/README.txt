# The data sets with different missing rates are generated randomly
    for missingrate in [0.1, 0.3, 0.5, 0.7]:

# Run the code by
    python run.py

# Requirement
    python==3.7.11
    numpy==1.20.1
    scikit-learn==0.22.2.post1
    scipy==1.6.2
    pytorch==1.9.0